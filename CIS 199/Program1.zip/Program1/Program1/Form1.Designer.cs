﻿namespace Program1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sqFeetInputLabel = new System.Windows.Forms.Label();
            this.coatsInputLabel = new System.Windows.Forms.Label();
            this.pricePerGallonInputLabel = new System.Windows.Forms.Label();
            this.sqFeetTextBox = new System.Windows.Forms.TextBox();
            this.coatsTextBox = new System.Windows.Forms.TextBox();
            this.pricePerGallonTextBox = new System.Windows.Forms.TextBox();
            this.sqFeetDisplayLabel = new System.Windows.Forms.Label();
            this.gallonsRequiredDisplayLabel = new System.Windows.Forms.Label();
            this.hoursRequiredDisplayLabel = new System.Windows.Forms.Label();
            this.costOfPaintDisplayLabel = new System.Windows.Forms.Label();
            this.costOfLaborDisplayLabel = new System.Windows.Forms.Label();
            this.totalCostDisplayLabel = new System.Windows.Forms.Label();
            this.sqFeetOutputLabel = new System.Windows.Forms.Label();
            this.gallonsRequiredOutputLabel = new System.Windows.Forms.Label();
            this.hoursRequiredOutputLabel = new System.Windows.Forms.Label();
            this.costOfPaintOutputLabel = new System.Windows.Forms.Label();
            this.costOfLaborOutputLabel = new System.Windows.Forms.Label();
            this.totalCostOutputLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // sqFeetInputLabel
            // 
            this.sqFeetInputLabel.AutoSize = true;
            this.sqFeetInputLabel.Location = new System.Drawing.Point(31, 22);
            this.sqFeetInputLabel.Name = "sqFeetInputLabel";
            this.sqFeetInputLabel.Size = new System.Drawing.Size(88, 13);
            this.sqFeetInputLabel.TabIndex = 0;
            this.sqFeetInputLabel.Text = "Enter square feet";
            // 
            // coatsInputLabel
            // 
            this.coatsInputLabel.AutoSize = true;
            this.coatsInputLabel.Location = new System.Drawing.Point(31, 50);
            this.coatsInputLabel.Name = "coatsInputLabel";
            this.coatsInputLabel.Size = new System.Drawing.Size(83, 13);
            this.coatsInputLabel.TabIndex = 1;
            this.coatsInputLabel.Text = "Enter # of coats";
            // 
            // pricePerGallonInputLabel
            // 
            this.pricePerGallonInputLabel.AutoSize = true;
            this.pricePerGallonInputLabel.Location = new System.Drawing.Point(31, 79);
            this.pricePerGallonInputLabel.Name = "pricePerGallonInputLabel";
            this.pricePerGallonInputLabel.Size = new System.Drawing.Size(107, 13);
            this.pricePerGallonInputLabel.TabIndex = 2;
            this.pricePerGallonInputLabel.Text = "Enter price per gallon";
            // 
            // sqFeetTextBox
            // 
            this.sqFeetTextBox.Location = new System.Drawing.Point(163, 22);
            this.sqFeetTextBox.Name = "sqFeetTextBox";
            this.sqFeetTextBox.Size = new System.Drawing.Size(100, 20);
            this.sqFeetTextBox.TabIndex = 3;
            // 
            // coatsTextBox
            // 
            this.coatsTextBox.Location = new System.Drawing.Point(163, 50);
            this.coatsTextBox.Name = "coatsTextBox";
            this.coatsTextBox.Size = new System.Drawing.Size(100, 20);
            this.coatsTextBox.TabIndex = 4;
            // 
            // pricePerGallonTextBox
            // 
            this.pricePerGallonTextBox.Location = new System.Drawing.Point(163, 79);
            this.pricePerGallonTextBox.Name = "pricePerGallonTextBox";
            this.pricePerGallonTextBox.Size = new System.Drawing.Size(100, 20);
            this.pricePerGallonTextBox.TabIndex = 5;
            // 
            // sqFeetDisplayLabel
            // 
            this.sqFeetDisplayLabel.AutoSize = true;
            this.sqFeetDisplayLabel.Location = new System.Drawing.Point(25, 130);
            this.sqFeetDisplayLabel.Name = "sqFeetDisplayLabel";
            this.sqFeetDisplayLabel.Size = new System.Drawing.Size(130, 13);
            this.sqFeetDisplayLabel.TabIndex = 6;
            this.sqFeetDisplayLabel.Text = "Square feet to be painted:";
            // 
            // gallonsRequiredDisplayLabel
            // 
            this.gallonsRequiredDisplayLabel.AutoSize = true;
            this.gallonsRequiredDisplayLabel.Location = new System.Drawing.Point(31, 144);
            this.gallonsRequiredDisplayLabel.Name = "gallonsRequiredDisplayLabel";
            this.gallonsRequiredDisplayLabel.Size = new System.Drawing.Size(124, 13);
            this.gallonsRequiredDisplayLabel.TabIndex = 7;
            this.gallonsRequiredDisplayLabel.Text = "Gallons of paint required:";
            // 
            // hoursRequiredDisplayLabel
            // 
            this.hoursRequiredDisplayLabel.AutoSize = true;
            this.hoursRequiredDisplayLabel.Location = new System.Drawing.Point(38, 158);
            this.hoursRequiredDisplayLabel.Name = "hoursRequiredDisplayLabel";
            this.hoursRequiredDisplayLabel.Size = new System.Drawing.Size(117, 13);
            this.hoursRequiredDisplayLabel.TabIndex = 8;
            this.hoursRequiredDisplayLabel.Text = "Hours of labor required:";
            // 
            // costOfPaintDisplayLabel
            // 
            this.costOfPaintDisplayLabel.AutoSize = true;
            this.costOfPaintDisplayLabel.Location = new System.Drawing.Point(86, 172);
            this.costOfPaintDisplayLabel.Name = "costOfPaintDisplayLabel";
            this.costOfPaintDisplayLabel.Size = new System.Drawing.Size(69, 13);
            this.costOfPaintDisplayLabel.TabIndex = 9;
            this.costOfPaintDisplayLabel.Text = "Cost of paint:";
            // 
            // costOfLaborDisplayLabel
            // 
            this.costOfLaborDisplayLabel.AutoSize = true;
            this.costOfLaborDisplayLabel.Location = new System.Drawing.Point(68, 186);
            this.costOfLaborDisplayLabel.Name = "costOfLaborDisplayLabel";
            this.costOfLaborDisplayLabel.Size = new System.Drawing.Size(87, 13);
            this.costOfLaborDisplayLabel.TabIndex = 10;
            this.costOfLaborDisplayLabel.Text = "Cost of the labor:";
            // 
            // totalCostDisplayLabel
            // 
            this.totalCostDisplayLabel.AutoSize = true;
            this.totalCostDisplayLabel.Location = new System.Drawing.Point(98, 218);
            this.totalCostDisplayLabel.Name = "totalCostDisplayLabel";
            this.totalCostDisplayLabel.Size = new System.Drawing.Size(57, 13);
            this.totalCostDisplayLabel.TabIndex = 11;
            this.totalCostDisplayLabel.Text = "Total cost:";
            // 
            // sqFeetOutputLabel
            // 
            this.sqFeetOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqFeetOutputLabel.Location = new System.Drawing.Point(163, 130);
            this.sqFeetOutputLabel.Name = "sqFeetOutputLabel";
            this.sqFeetOutputLabel.Size = new System.Drawing.Size(100, 14);
            this.sqFeetOutputLabel.TabIndex = 12;
            // 
            // gallonsRequiredOutputLabel
            // 
            this.gallonsRequiredOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsRequiredOutputLabel.Location = new System.Drawing.Point(163, 144);
            this.gallonsRequiredOutputLabel.Name = "gallonsRequiredOutputLabel";
            this.gallonsRequiredOutputLabel.Size = new System.Drawing.Size(100, 14);
            this.gallonsRequiredOutputLabel.TabIndex = 13;
            // 
            // hoursRequiredOutputLabel
            // 
            this.hoursRequiredOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hoursRequiredOutputLabel.Location = new System.Drawing.Point(163, 158);
            this.hoursRequiredOutputLabel.Name = "hoursRequiredOutputLabel";
            this.hoursRequiredOutputLabel.Size = new System.Drawing.Size(100, 14);
            this.hoursRequiredOutputLabel.TabIndex = 14;
            // 
            // costOfPaintOutputLabel
            // 
            this.costOfPaintOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.costOfPaintOutputLabel.Location = new System.Drawing.Point(163, 172);
            this.costOfPaintOutputLabel.Name = "costOfPaintOutputLabel";
            this.costOfPaintOutputLabel.Size = new System.Drawing.Size(100, 14);
            this.costOfPaintOutputLabel.TabIndex = 15;
            // 
            // costOfLaborOutputLabel
            // 
            this.costOfLaborOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.costOfLaborOutputLabel.Location = new System.Drawing.Point(163, 186);
            this.costOfLaborOutputLabel.Name = "costOfLaborOutputLabel";
            this.costOfLaborOutputLabel.Size = new System.Drawing.Size(100, 14);
            this.costOfLaborOutputLabel.TabIndex = 16;
            // 
            // totalCostOutputLabel
            // 
            this.totalCostOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostOutputLabel.Location = new System.Drawing.Point(163, 218);
            this.totalCostOutputLabel.Name = "totalCostOutputLabel";
            this.totalCostOutputLabel.Size = new System.Drawing.Size(100, 14);
            this.totalCostOutputLabel.TabIndex = 17;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(176, 238);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 18;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalCostOutputLabel);
            this.Controls.Add(this.costOfLaborOutputLabel);
            this.Controls.Add(this.costOfPaintOutputLabel);
            this.Controls.Add(this.hoursRequiredOutputLabel);
            this.Controls.Add(this.gallonsRequiredOutputLabel);
            this.Controls.Add(this.sqFeetOutputLabel);
            this.Controls.Add(this.totalCostDisplayLabel);
            this.Controls.Add(this.costOfLaborDisplayLabel);
            this.Controls.Add(this.costOfPaintDisplayLabel);
            this.Controls.Add(this.hoursRequiredDisplayLabel);
            this.Controls.Add(this.gallonsRequiredDisplayLabel);
            this.Controls.Add(this.sqFeetDisplayLabel);
            this.Controls.Add(this.pricePerGallonTextBox);
            this.Controls.Add(this.coatsTextBox);
            this.Controls.Add(this.sqFeetTextBox);
            this.Controls.Add(this.pricePerGallonInputLabel);
            this.Controls.Add(this.coatsInputLabel);
            this.Controls.Add(this.sqFeetInputLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sqFeetInputLabel;
        private System.Windows.Forms.Label coatsInputLabel;
        private System.Windows.Forms.Label pricePerGallonInputLabel;
        private System.Windows.Forms.TextBox sqFeetTextBox;
        private System.Windows.Forms.TextBox coatsTextBox;
        private System.Windows.Forms.TextBox pricePerGallonTextBox;
        private System.Windows.Forms.Label sqFeetDisplayLabel;
        private System.Windows.Forms.Label gallonsRequiredDisplayLabel;
        private System.Windows.Forms.Label hoursRequiredDisplayLabel;
        private System.Windows.Forms.Label costOfPaintDisplayLabel;
        private System.Windows.Forms.Label costOfLaborDisplayLabel;
        private System.Windows.Forms.Label totalCostDisplayLabel;
        private System.Windows.Forms.Label sqFeetOutputLabel;
        private System.Windows.Forms.Label gallonsRequiredOutputLabel;
        private System.Windows.Forms.Label hoursRequiredOutputLabel;
        private System.Windows.Forms.Label costOfPaintOutputLabel;
        private System.Windows.Forms.Label costOfLaborOutputLabel;
        private System.Windows.Forms.Label totalCostOutputLabel;
        private System.Windows.Forms.Button calculateButton;
    }
}

