﻿//Grading ID: B6980
//Due 10.16.2016
//CIS 199-75
//Program 2
//This program takes input from a user through textboxes and uses nested if statements to determine the earliest
//date they can register. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Program2 : Form
    {

        public const string TIME_SLOT_1 = "8:30 AM";  //Constant for earliest time slot
        public const string TIME_SLOT_2 = "10:00 AM"; //Constant for second earliest time slot
        public const string TIME_SLOT_3 = "11:30 AM"; //Constant for third earliest time slot
        public const string TIME_SLOT_4 = "2:00 PM"; //Constant for fourth earliest time slot
        public const string TIME_SLOT_5 = "4:00 PM"; //Constant for last time slot
        public const double SOPHOMORE_CREDIT_HOURS = 30; //Constant for how many credit hours needed to be a sophomore
        public const double JUNIOR_CREDIT_HOURS = 60; //Constant for how many credit hours needed to be a junior
        public const double SENIOR_CREDIT_HOURS = 90; //Constant for how many credit hours needed to be a senior
        public const string SENIOR_DATE = "Friday, Nov 4"; //Constant for dates seniors register on
        public const string JUNIOR_DATE = "Monday, Nov 7"; //Constant for date juniors register on
        public const string SOPHOMORE_DATE_1 = "Wednesday, Nov 9"; //Constant for first date of sophomore registration
        public const string SOPHOMORE_DATE_2 = "Thursday, Nov 10"; //Constant for second date of sophomore registration
        public const string FRESHMAN_DATE_1 = "Friday, Nov 11"; //Constant for first date of freshman registration
        public const string FRESHMAN_DATE_2 = "Monday, Nov 14"; //Constant for seccond date of freshman registration



        public Program2()
        {
            InitializeComponent();
        }
        
        //Click event that takes the input from the user and performs all calculations to test the earliest date
        //the user can register on using nested if logic.
        private void calculateButton_Click(object sender, EventArgs e)
        {
            string lastName = lastNameTextBox.Text.ToLower(); //Stores the entire last name entered by the user
            char firstLetter = lastName[0]; //Retrieves and stores the first letter of the last name entered by the user
            double creditHours; //Amount of credit hours which will be entered by the user
            Boolean isValidInput; //Represents if the user inputted valid data into the textboxes
            Boolean isSenior; //Represents if the user is a senior
            Boolean isFreshman; //Represents if the user is a freshman

            //Parses the creditHours textbox to make sure a positive number is entered.
            if (double.TryParse(creditHoursTextBox.Text, out creditHours)&& creditHours >= 0)
                isValidInput = true;
            else
            {
                isValidInput = false;
                MessageBox.Show("Enter a valid number for credit hours.");
            }


            //Tests if the user is a senior
            if (creditHours >= SENIOR_CREDIT_HOURS)
                isSenior = true;
            else
                isSenior = false;
            //Tests if the user is a freshman.
            if (creditHours < SOPHOMORE_CREDIT_HOURS)
                isFreshman = true;
            else
                isFreshman = false;

            //Nested if that outputs the earliest registration date if the user is a junior or senior.
            if (creditHours >= JUNIOR_CREDIT_HOURS && isValidInput)
            {
                if (firstLetter <= 'd')
                {
                    //Juniors and seniors have the same pattern so the only difference is the date.
                    //This test determines if the user is a senior or junior and outputs the appropriate date.
                    //This logic is used for the remaining else if's and is also used in the freshman and sophomore
                    //section of the code.
                    if (isSenior) 
                        MessageBox.Show(SENIOR_DATE + " " + TIME_SLOT_4);
                    else
                        MessageBox.Show(JUNIOR_DATE + " " + TIME_SLOT_4);
                }
                else if (firstLetter <= 'i')
                {
                    if (isSenior)
                        MessageBox.Show(SENIOR_DATE + " " + TIME_SLOT_5);
                    else
                        MessageBox.Show(JUNIOR_DATE + " " + TIME_SLOT_5);
                }
                else if (firstLetter <= 'o')
                {
                    if (isSenior)
                        MessageBox.Show(SENIOR_DATE + " " + TIME_SLOT_1);
                    else
                        MessageBox.Show(JUNIOR_DATE + " " + TIME_SLOT_1);
                }
                else if (firstLetter <= 's')
                {
                    if (isSenior)
                        MessageBox.Show(SENIOR_DATE + " " + TIME_SLOT_2);
                    else
                        MessageBox.Show(JUNIOR_DATE + " " + TIME_SLOT_2);
                }
                else
                {
                    if (isSenior)
                        MessageBox.Show(SENIOR_DATE + " " + TIME_SLOT_3);
                    else
                        MessageBox.Show(JUNIOR_DATE + " " + TIME_SLOT_3);
                }
            }

            //Nested if that outputs the earliest registration date if the user is a freshman or sophomore
            //using the same logic from the junior and senior portion.
            if(creditHours < JUNIOR_CREDIT_HOURS && isValidInput)
                {
                if (firstLetter<='b')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_2 + " " + TIME_SLOT_2);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_2 + " " + TIME_SLOT_2);
                }
                else if (firstLetter<='d')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_2 + " " + TIME_SLOT_3);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_2 + " " + TIME_SLOT_3);
                }
                else if (firstLetter <= 'f')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_2 + " " + TIME_SLOT_4);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_2 + " " + TIME_SLOT_4);
                }
                else if (firstLetter <= 'i')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_2 + " " + TIME_SLOT_5);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_2 + " " + TIME_SLOT_5);
                }
                else if (firstLetter <= 'l')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_1 + " " + TIME_SLOT_1);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_1 + " " + TIME_SLOT_1);
                }
                else if (firstLetter <= 'o')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_1 + " " + TIME_SLOT_2);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_1 + " " + TIME_SLOT_2);
                }
                else if (firstLetter <= 'q')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_1 + " " + TIME_SLOT_3);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_1 + " " + TIME_SLOT_3);
                }
                else if (firstLetter <= 's')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_1 + " " + TIME_SLOT_4);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_1 + " " + TIME_SLOT_4);
                }
                else if (firstLetter <= 'v')
                {
                    if (isFreshman)
                        MessageBox.Show(FRESHMAN_DATE_1 + " " + TIME_SLOT_5);
                    else
                        MessageBox.Show(SOPHOMORE_DATE_1 + " " + TIME_SLOT_5);
                }
                else
                   if (isFreshman)
                    MessageBox.Show(FRESHMAN_DATE_2 + " " + TIME_SLOT_1);
                   else
                    MessageBox.Show(SOPHOMORE_DATE_2 + " " + TIME_SLOT_1);
            }

        }
    }
}
