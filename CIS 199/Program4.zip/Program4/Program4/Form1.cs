﻿//Grading ID: B6980
//Program 4
//12/06/2016
//CIS 199-75
//This program models a simple library, allowing books to be created, examined, checked out, and returned.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        List<LibraryBook> bookList = new List<LibraryBook>(); //List to hold all the created LibraryBook's 


        //Creates a LibraryBook object from the users input, stores it in the bookList, and adds the title to the listBox
        private void createBookButton_Click(object sender, EventArgs e)
        {
            int copyrightYear; //Used to validate copyright year 

            //Input validation
            if (!string.IsNullOrWhiteSpace(titleTextBox.Text))
            {
                if (!string.IsNullOrWhiteSpace(authorTextBox.Text))
                {
                    if (!string.IsNullOrWhiteSpace(publisherTextBox.Text))
                    {
                        if (int.TryParse(copyrightYearTextBox.Text, out copyrightYear))
                        {
                            if (!string.IsNullOrWhiteSpace(callNumberTextBox.Text))
                            {
                                //The book is created using the validated input 
                                LibraryBook book = new LibraryBook(titleTextBox.Text, authorTextBox.Text,
                                    publisherTextBox.Text, copyrightYear, callNumberTextBox.Text);

                                //The book is added to the list
                                bookList.Add(book);

                                //The title is added to the ListBox
                                bookListBox.Items.Add(book.Title);

                                //The textboxes are cleared
                                titleTextBox.Clear();
                                authorTextBox.Clear();
                                publisherTextBox.Clear();
                                copyrightYearTextBox.Clear();
                                callNumberTextBox.Clear();
                            }
                            else
                                MessageBox.Show("Please enter a call number."); 
                        }
                        else
                            MessageBox.Show("Please enter an integer for copyright year.");
                    }
                    else
                        MessageBox.Show("Please enter a publisher.");
                }
                else
                    MessageBox.Show("Please enter an author.");
            }
            else
                MessageBox.Show("Please enter a title.");
            


          
        }

        //Displays the details of the selected book in the listBox
        private void detailsButton_Click(object sender, EventArgs e)
        {
            if (bookListBox.SelectedIndex >= 0)
            {
                MessageBox.Show(bookList[bookListBox.SelectedIndex].ToString());
            }
            else
                MessageBox.Show("Please select a book.");
        }

        //Checks out a book and displays a message confirming that to the user
        //If the book is already checked out the user is notified
        private void checkOutButton_Click(object sender, EventArgs e)
        {
            if (bookListBox.SelectedIndex >= 0)
            {
                if (!bookList[bookListBox.SelectedIndex].IsCheckedOut())
                {
                    bookList[bookListBox.SelectedIndex].CheckOut();
                    MessageBox.Show(bookList[bookListBox.SelectedIndex].Title + " was checked out.");
                }
                else
                    MessageBox.Show("This book is already checked out.");
            }
            else
                MessageBox.Show("Please select a book.");
        }

        //Returns a book and displays a message confirming that to the user
        //If the book is not checked out the user is notified
        private void returnButton_Click(object sender, EventArgs e)
        {
            if (bookListBox.SelectedIndex >= 0)
            {
                if (bookList[bookListBox.SelectedIndex].IsCheckedOut())
                {
                    bookList[bookListBox.SelectedIndex].ReturnToShelf();
                    MessageBox.Show(bookList[bookListBox.SelectedIndex].Title + " was returned.");
                }
                else
                    MessageBox.Show("This book is not checked out.");
            }
            else
                MessageBox.Show("Please select a book.");
        }
    }
}
