﻿//Grading ID: B6980
//Program 4
//12/06/2016
//CIS 199-75


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    //This class models a simple library book, keeps track of titles, author, publisher, copyright year, call number, and checked out status.
    class LibraryBook
    {

        private string _title; //Backing field for the Title property
        private string _author; //Backing field for the Author property
        private string _publisher; //Backing field for the Publisher property
        private int _copyrightYear; //Backing field for the CopyrightYear property
        private string _callNumber; //Backing field for the CallNumber property
        private bool checkedOut; //Book checked out status

        //Pre-condition: 5 parameters of valid type
        //Post-condition: A LibraryBook is created with the given arguments passed into the properties and checkedOut is set to false
        public LibraryBook(string title, string author, string publisher, int copyrightYear, string callNumber)
        {
            Title = title;
            Author = author;
            Publisher = publisher;
            CopyrightYear = copyrightYear;
            CallNumber = callNumber;
            checkedOut = false;
        }

         public string Title
        {
            //Pre-condition: None
            //Post-condition: The title is returned.
            get { return _title; }
            
            //Pre-condition: None
            //Post-condition: The title is set to value.
            set
            {
                _title = value;
            }
        }

        public string Author
        {
            //Pre-condition: None
            //Post-condition: The author is returned.
            get { return _author; }

            //Pre-condition: None
            //Post-condition: The author is set to value.
            set
            {
                _author = value;
            }
        }
        public string Publisher
        {
            //Pre-condition: None
            //Post-condition: The publisher is returned.
            get { return _publisher; }

            //Pre-condition: None
            //Post-condition: The publisher is set to value.
            set
            {
                _publisher = value;
            }
        }
        public int CopyrightYear
        {
            //Pre-condition: None
            //Post-condition: The copyright year is returned.
            get { return _copyrightYear; }

            //Pre-condition: value >= 0
            //Post-condition: The copyright year is set to value.
            set
            {
                if (value >= 0)
                    _copyrightYear = value;
                else
                    _copyrightYear = 2016;
               
            }
        }
        public string CallNumber
        {
            //Pre-condition: None
            //Post-condition: The call number is returned.
            get { return _callNumber; }

            //Pre-condition: None
            //Post-condition: The call number is set to value.
            set
            {
                _callNumber = value;
            }
        }

        //Pre-condition: None
        //Post-condition: checkedOut is set to True.
        public void CheckOut()
        {
            checkedOut = true;
        }

        //Pre-condition: None
        //Post-condition: checkedOut is set to False.
        public void ReturnToShelf()
        {
            checkedOut = false;
        }

        //Pre-condition: None
        //Post-condition: checkedOut is returned.
        public bool IsCheckedOut()
        {
            return checkedOut;
        }

        //This method exists to better format the ToString method
        //Pre-condition: None
        //Post-condition: "Yes" or "No" is returned based on checkedOut
        private string CheckedOutYesOrNo()
        {
            if (checkedOut)
                return "Yes";
            else
                return "No";
        }


        //Pre-condition: None
        //Post-condition: A formatted version of the books information is returned.
        public override string ToString()
        {
            return "Title: " + Title + Environment.NewLine
                + "Author: " + Author + Environment.NewLine
                + "Publisher: " + Publisher + Environment.NewLine
                + "Copyright Year: " + CopyrightYear.ToString() + Environment.NewLine
                + "Call Number: " + CallNumber + Environment.NewLine
                + "Checked out: " + CheckedOutYesOrNo();

        }


    }
}
