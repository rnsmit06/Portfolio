﻿//Program 0
//Grading ID:  D1972
//Due 1/29/2017
//CIS 200-01
// File: LibraryPatron.cs
// This file creates a simple LibraryPatron class capable of tracking
// the patron's name and ID.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class LibraryPatron
{
    private string _patronName; // Name of the patron
    private string _patronID;   // ID of the patron

    // Precondition:  None
    // Postcondition: The patron has been initialized with the specified name
    //                and ID
    public LibraryPatron(string name, string id)
    {
        PatronName = name;
        PatronID = id;
    }

    public string PatronName
    {
        // Precondition:  None
        // Postcondition: The patron's name has been returned
        get
        {
            return _patronName;
        }

        // Precondition:  Value must not be null or empty
        // Postcondition: The patron's name has been set to the specified value
        set
        {
            value.Trim();
            if(!String.IsNullOrEmpty(value))
            {
                _patronName = value;
            }
            else
            {
                throw new ArgumentOutOfRangeException();
            }
           
        }
    }

    public string PatronID
    {
        // Precondition:  None
        // Postcondition: The patron's ID has been returned
        get
        {
            return _patronID;
        }

        // Precondition:  Value must not be null or empty
        // Postcondition: The patron's ID has been set to the specified value
        set
        {
            value.Trim();
            if (!String.IsNullOrEmpty(value))
            {
                _patronID = value;
            }
            else
            {
                throw new ArgumentOutOfRangeException();
            }

        }
    }

    // Precondition:  None
    // Postcondition: A string is returned presenting the libary patron's data on
    //                separate lines
    public override string ToString()
    {
        string NL = Environment.NewLine; // NewLine shortcut

        return $"Name: {PatronName}{NL}ID: {PatronID}";
    }

}

