﻿//Program 0
//Grading ID:  D1972
//Due 1/29/2017
//CIS 200-01
// File: LibraryBook.cs
// This file creates a simple LibraryBook class capable of tracking
// the book's title, author, publisher, copyright year, call number,
// and checked out status.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


public class LibraryBook
{
    public const int DEFAULT_YEAR = 2016; // Default copyright year

    private string _title;      // The book's title
    private string _author;     // The book's author
    private string _publisher;  // The book's publisher
    private int _copyrightYear; // The book's year of copyright
    private string _callNumber; // The book's call number in the library
    private bool _checkedOut;   // The book's checked out status
    private LibraryPatron _patron = null; //The patron who checked out the book, defaults to null

    // Precondition:  theCopyrightYear >= 0
    // Postcondition: The library book has been initialized with the specified
    //                values for title, author, publisher, copyright year, and
    //                call number. The book is not checked out.
    public LibraryBook(string theTitle, string theAuthor, string thePublisher,
        int theCopyrightYear, string theCallNumber)
    {
        Title = theTitle;
        Author = theAuthor;
        Publisher = thePublisher;
        CopyrightYear = theCopyrightYear;
        CallNumber = theCallNumber;

        ReturnToShelf(); // Make sure book is not checked out
    }

    public LibraryPatron Patron
    {
        //Precondition: None
        //Postcondition: The patron has been returned
        get
        {
            return _patron;
        }

        //Precondition: The book must be checkedout
        //Postcondition: The patron has been set to the specified value
        private set
        {
            if (IsCheckedOut())
            {
                _patron = value;
            }
        }
    }
        
    public string Title
    {
        // Precondition:  None
        // Postcondition: The title has been returned
        get
        {
            return _title;
        }

        // Precondition:  Value must not be null or empty.
        // Postcondition: The title has been set to the specified value
        set
        {
            value.Trim();
            if (!String.IsNullOrEmpty(value))
            {
                _title = value;
            }
            else
            {
                throw new ArgumentOutOfRangeException();
            }

        }
    }

    public string Author
    {
        // Precondition:  None
        // Postcondition: The author has been returned
        get
        {
            return _author;
        }

        // Precondition:  None
        // Postcondition: The author has been set to the specified value
        set
        {
            _author = value;
        }
    }

    public string Publisher
    {
        // Precondition:  None
        // Postcondition: The publisher has been returned
        get
        {
            return _publisher;
        }

        // Precondition:  None
        // Postcondition: The publisher has been set to the specified value
        set
        {
            _publisher = value;
        }
    }

    public int CopyrightYear
    {
        // Precondition:  None
        // Postcondition: The copyright year has been returned
        get
        {
            return _copyrightYear;
        }

        // Precondition:  value >= 0
        // Postcondition: The copyright year has been set to the specified value
        set
        {
            if (value >= 0)
                _copyrightYear = value;
            else
                throw new ArgumentOutOfRangeException();
        }
    }

    public string CallNumber
    {
        // Precondition:  None
        // Postcondition: The call number has been returned
        get
        {
            return _callNumber;
        }

        // Precondition:  Value must not be null or empty   
        // Postcondition: The call number has been set to the specified value
        set
        {
            value.Trim();
            if (!String.IsNullOrEmpty(value))
            {
                _callNumber = value;
            }
            else
            {
                throw new ArgumentOutOfRangeException();
            }

        }
    }

    // Precondition:  None
    // Postcondition: The book is checked out and associated with a patron
    public void CheckOut(LibraryPatron patron)
    {
        _checkedOut = true;
        Patron = patron;
    }

    // Precondition:  None
    // Postcondition: The book is not checked out and no patorn is associated with it
    public void ReturnToShelf()
    {
        Patron = null;
        _checkedOut = false;
        
    }

    // Precondition:  None
    // Postcondition: true is returned if the book is checked out,
    //                otherwise false is returned
    public bool IsCheckedOut()
    {
        return _checkedOut;
    }

    // Precondition:  None
    // Postcondition: A string is returned presenting the libary book's data on
    //                separate lines
    public override string ToString()
    {

        if (IsCheckedOut())
        {
            return $"Title: " + Title + System.Environment.NewLine +
                $"Author: " + Author + System.Environment.NewLine +
                $"Publisher: " + Publisher + System.Environment.NewLine +
                $"Copyright: " + CopyrightYear.ToString("D4") + System.Environment.NewLine +
                $"Checked out by: " + System.Environment.NewLine +
                $"{Patron}";
        }
        else
        {
            return $"Title: " + Title + System.Environment.NewLine +
       $"Author: " + Author + System.Environment.NewLine +
       $"Publisher: " + Publisher + System.Environment.NewLine +
       $"Copyright: " + CopyrightYear.ToString("D4") + System.Environment.NewLine +
       $"Not checked out";


        }


           
    }
}
