﻿// Program 3
// CIS 200-01
// Due: 4/5/2017
// By: D1972
// This class creates the select patron form GUI. It displays a ComboBox
// and populates it with Patrons. A patron can be selected and edited.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class SelectPatron : Form
    {
        private List<LibraryPatron> _patrons; // List of library patrons


        // Precondition:  List patrons is populated with the patrons
        //                to choose from
        // Postcondition: The form's GUI is prepared for display.
        public SelectPatron(List<LibraryPatron> patronList)
        {
            InitializeComponent();
            _patrons = patronList;
        }

        // Precondition:  None
        // Postcondition: The form's ComboBox is populated with the patrons.
        private void SelectPatron_Load(object sender, EventArgs e)
        {
            foreach (LibraryPatron p in _patrons)
                patronComboBox.Items.Add(p.PatronName + ", " + p.PatronID);
        }


        internal string UpdatePatronName
        {
            // Precondition:  None
            // Postcondition: The patron name is returned
            get;
            // Precondition:  None
            // Postcondition: The patron name is set
            set;
        }
        internal string UpdatePatronID
        {
            // Precondition:  None
            // Postcondition: The patronID is returned
            get;
            // Precondition:  None
            // Postcondition: The patron ID is set
            set;
        }
        internal int UpdatePatronIndex
        {
            // Precondition:  None
            // Postcondition: The index for the patron is returned
            get;
            // Precondition:  None
            // Postcondition: The patron index is set
            set;
        }


        //Precondition: A patron has been selected
        //Postcondition: A PatronForm is displayed and any changes made to the data in the form will be stored in
        //the properties of both forms.
        private void editButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (patronComboBox.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select a patron");
                }
                PatronForm patronForm = new PatronForm(); // The patron dialog box form
                patronForm.PatronName = _patrons[patronComboBox.SelectedIndex].PatronName;
                patronForm.PatronID = _patrons[patronComboBox.SelectedIndex].PatronID;
                DialogResult result = patronForm.ShowDialog(); // Show form as dialog and store result

                if (result == DialogResult.OK)
                {
                    UpdatePatronName = patronForm.PatronName;
                    UpdatePatronID = patronForm.PatronID;
                    UpdatePatronIndex = patronComboBox.SelectedIndex;

                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("An error has occurred please try again");
            }
            
        }
    }
}
