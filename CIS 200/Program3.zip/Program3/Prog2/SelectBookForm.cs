﻿// Program 3
// CIS 200-01
// Due: 4/5/2017
// By: D1972
// This class creates the select book form GUI. It displays a ComboBox
// and populates it with LibraryBooks. A book can be selected and edited

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class SelectBookForm : Form
    {
        private List<LibraryItem> _books; // List of library books


        // Precondition:  List _books is populated with the LibraryBooks
        //                to choose from
        // Postcondition: The form's GUI is prepared for display.
        public SelectBookForm(List<LibraryItem> bookList)
        {
            _books = bookList;
        }

        // Precondition:  none
        // Postcondition: The form's ComboBox is populated
        private void SelectBookForm_Load(object sender, EventArgs e)
        {
            foreach(LibraryBook b in _books)
            {
                bookComboBox.Items.Add(b);
            }
        }

        internal int SelectedBookIndex
        {
            // Precondition:  None
            // Postcondition: The selected index of bookComboBox is returned
            get
            {
                return bookComboBox.SelectedIndex;
            }
            // Precondition:  None
            // Postcondition: The selected index of bookComboBox is set
            set
            {
                SelectedBookIndex = bookComboBox.SelectedIndex;
            }
        }

        internal String UpdateBookAuthor
        {
            // Precondition:  None
            // Postcondition: The book author is returned
            get;
            // Precondition:  None
            // Postcondition: The book author is set
            set;
        }
        internal string UpdateBookPublisher
        {
            // Precondition:  None
            // Postcondition: The book publisher is returned
            get;
            // Precondition:  None
            // Postcondition: The book publisher is set
            set;
        }
        internal String UpdateBookTitle
        {
            // Precondition:  None
            // Postcondition: The book title is returned
            get;
            // Precondition:  None
            // Postcondition: The book title is set
            set;
        }
        internal string UpdateBookCallNumber
        {
            // Precondition:  None
            // Postcondition: The book call number is returned
            get;
            // Precondition:  None
            // Postcondition: The book call number is set
            set;
        }
        internal string UpdateBookLoanPeriod
        {
            // Precondition:  None
            // Postcondition: The book loan period is returned
            get;
            // Precondition:  None
            // Postcondition: The book loan period is set
            set;
        }
        internal string UpdateBookCopyrightYear
        {
            // Precondition:  None
            // Postcondition: The book copyright year is returned
            get;
            // Precondition:  None
            // Postcondition: The book copyright year is set
            set;
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            BookForm bookForm = new BookForm(); // The dialog box form
            bookForm.ItemTitle = _books[bookComboBox.SelectedIndex].Title;
            bookForm.ItemPublisher = _books[bookComboBox.SelectedIndex].Publisher;
            bookForm.ItemLoanPeriod = _books[bookComboBox.SelectedIndex].LoanPeriod.ToString();
            bookForm.ItemCopyrightYear = _books[bookComboBox.SelectedIndex].CopyrightYear.ToString();
            bookForm.ItemCallNumber = _books[bookComboBox.SelectedIndex].CallNumber;
            DialogResult result = bookForm.ShowDialog(); // Show form as dialog and store result

            if (result == DialogResult.OK)
            {
                UpdateBookAuthor = bookForm.BookAuthor;
                UpdateBookCallNumber = bookForm.ItemCallNumber;
                UpdateBookCopyrightYear = bookForm.ItemCopyrightYear.ToString();
                UpdateBookLoanPeriod = bookForm.ItemLoanPeriod;
                UpdateBookPublisher = bookForm.ItemPublisher;
                UpdateBookTitle = bookForm.ItemTitle;
                this.Close();
            }

        }
    }
}
