﻿// Program 5
// CIS 200-01
// Spring 2017
// By: D1972

// File: Library.cs
// This file creates a basic Library class that stores a dict
// of LibraryItems and a dict of LibraryPatrons. It allows items
// to be checked out by patrons. The dicts are accessible to other
// classes in the same namespace (LibraryItems).
// Now Serializable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    [Serializable]
    public class Library
    {
        // Namespace Accessible Data - Use with care
        internal List<LibraryItem> _items;     // List of items stored in Library
        internal List<LibraryPatron> _patrons; // List of patrons of Library

        internal Dictionary<string, LibraryItem> items = new Dictionary<string, LibraryItem>();         //Dictionary of items stored in library, callNumber = key, LibraryItem = value
        internal Dictionary<string, LibraryPatron> patrons = new Dictionary<string, LibraryPatron>();   //Dictionary of patrons stored in library, patronID = key, Patron = value
        internal Dictionary<string, DateTime> checkouts = new Dictionary<string, DateTime>();           //Dictionary to keep track of when books are checked out, callNumber = key, dateCheckedOut = value

        // Precondition:  None
        // Postcondition: The library has been created and is empty (no books, no patrons)
        public Library()
        {
            _items = new List<LibraryItem>();
            _patrons = new List<LibraryPatron>();
            items = new Dictionary<string, LibraryItem>();
            patrons = new Dictionary<string, LibraryPatron>();

        }

        // Precondition:  None
        // Postcondition: A patron has been created with the specified values for name and ID.
        //                The patron has been added to the Library.
        public bool AddPatron(String name, String id)
        {
            try
            {
                LibraryPatron p = new LibraryPatron(name, id);
                patrons.Add(id, p);
                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }

        // Precondition:  theCopyrightYear >= 0 and theLoanPeriod >= 0
        // Postcondition: A library book has been created with the specified
        //                values for title, publisher, copyright year, loan period, 
        //                call number, and author. The item is not checked out.
        //                The book has been added to the Library.
        public bool AddLibraryBook(String theTitle, String thePublisher, int theCopyrightYear,
            int theLoanPeriod, String theCallNumber, String theAuthor)
        {
            try
            {
                LibraryBook b = new LibraryBook(theTitle, thePublisher, theCopyrightYear, theLoanPeriod,
                theCallNumber, theAuthor);
                items.Add(theCallNumber, b);
                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }

        }

        // Precondition:  theCopyrightYear >= 0 and theLoanPeriod >= 0 and 
        //                theMedium from { DVD, BLURAY, VHS } and theDuration >= 0
        // Postcondition: A library movie has been created with the specified
        //                values for title, publisher, copyright year, loan period, 
        //                call number, duration, director, medium, and rating. The
        //                item is not checked out.
        //                The movie has been added to the Library.
        public bool AddLibraryMovie(String theTitle, String thePublisher, int theCopyrightYear,
            int theLoanPeriod, String theCallNumber, double theDuration, String theDirector,
            LibraryMediaItem.MediaType theMedium, LibraryMovie.MPAARatings theRating)
        {

            try
            {
                LibraryMovie m = new LibraryMovie(theTitle, thePublisher, theCopyrightYear, theLoanPeriod,
                theCallNumber, theDuration, theDirector, theMedium, theRating);
                items.Add(theCallNumber, m);
                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }

        // Precondition:  theCopyrightYear >= 0 and theLoanPeriod >= 0 and 
        //                theMedium from { CD, SACD, VINYL } and theDuration >= 0 and
        //                theNumTracks >= 0
        // Postcondition: A library music item has been created with the specified
        //                values for title, publisher, copyright year, loan period, 
        //                call number, duration, director, medium, and rating. The
        //                item is not checked out.
        //                The music item has been added to the Library.
        public bool AddLibraryMusic(String theTitle, String thePublisher, int theCopyrightYear,
            int theLoanPeriod, String theCallNumber, double theDuration, String theArtist,
            LibraryMediaItem.MediaType theMedium, int theNumTracks)
        {
            try
            {
                LibraryMusic m = new LibraryMusic(theTitle, thePublisher, theCopyrightYear,
            theLoanPeriod, theCallNumber, theDuration, theArtist,
            theMedium, theNumTracks);
                items.Add(theCallNumber, m);
                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }

        // Precondition:  theCopyrightYear >= 0 and theLoanPeriod >= 0 and
        //                theVolume >= 0 and theNumber >= 0
        // Postcondition: A library journal has been created with the specified
        //                values for title, publisher, copyright year, loan period, 
        //                call number, volume, number, discipline, and editor. The
        //                item is not checked out.
        //                The journal has been added to the Library.
        public bool AddLibraryJournal(String theTitle, String thePublisher, int theCopyrightYear,
            int theLoanPeriod, String theCallNumber, int theVolume, int theNumber,
            String theDiscipline, String theEditor)
        {

            try
            {
                LibraryJournal j = new LibraryJournal(theTitle, thePublisher, theCopyrightYear,
            theLoanPeriod, theCallNumber, theVolume, theNumber,
            theDiscipline, theEditor);
                items.Add(theCallNumber, j);
                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }

        // Precondition:  theCopyrightYear >= 0 and theLoanPeriod >= 0 and
        //                theVolume >= 0 and theNumber >= 0
        // Postcondition: A library magazine has been created with the specified
        //                values for title, publisher, copyright year, loan period, 
        //                call number, volume, and number. The item is not checked out.
        //                The magazine has been added to the Library.
        public bool AddLibraryMagazine(String theTitle, String thePublisher, int theCopyrightYear,
            int theLoanPeriod, String theCallNumber, int theVolume, int theNumber)
        {
            try
            {
                LibraryMagazine m = new LibraryMagazine(theTitle, thePublisher, theCopyrightYear,
            theLoanPeriod, theCallNumber, theVolume, theNumber);
                items.Add(theCallNumber, m);
                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }

        // Precondition:  None
        // Postcondition: The number of patrons in the library is returned
        public int GetPatronCount()
        {
            return patrons.Count();
        }

        // Precondition:  None
        // Postcondition: The number of items in the library is returned
        public int GetItemCount()
        {
            return items.Count;
        }

        // Precondition:  0 <= itemIndex < GetItemCount()
        //                0 <= patronIndex < GetPatronCount()
        // Postcondition: The specified item will be checked out by
        //                the specifed patron
        public bool CheckOut(string callNumber, string patronID)
        {
            if (items.ContainsKey(callNumber) && patrons.ContainsKey(patronID) && !items[callNumber].IsCheckedOut())
            {
                items[callNumber].CheckOut(patrons[patronID]);
                checkouts.Add(callNumber, DateTime.Today.AddDays(-21));
                return true;
            }
            else
                return false;
        }

        // Precondition:  An item with the callNumber is in the library and checked out
        // Postcondition: The specified book will be returned to shelf and it's late fee will be returned
        public decimal ReturnToShelf(string callNumber)
        {
   
            if (items.ContainsKey(callNumber) && items[callNumber].IsCheckedOut())
            {

                items[callNumber].ReturnToShelf();  //Return the item

                //Calculates time between now and when the item was checked out.
                TimeSpan t = DateTime.Today-checkouts[callNumber].AddDays(items[callNumber].LoanPeriod);                                                                                                                                                    
                double dayslate = t.TotalDays; //holds the number of days between now and when item was checked out
                if (dayslate >= 1)
                {
                    return items[callNumber].CalcLateFee((int)dayslate); //the items late fee
                }
                else
                    return 0; //the item was not overdue 
            }
            else
                return -1; //the item was not checked out
        }

        // Precondition:  None
        // Postcondition: The number of items checked out from the library is returned
        public int GetCheckedOutCount()
        {
            int checkedOutCount = 0; // Running count of checked out books

            foreach (LibraryItem item in _items)
                if (item.IsCheckedOut())
                    ++checkedOutCount;

            return checkedOutCount;
        }

        //Precondition: None
        //Postcondition: The dictionary containing the checkout transactions is returned
        internal Dictionary<string, DateTime> GetCheckedOutTransactions()
        {
            return checkouts;
        }

        // Namespace Helper Method - Use with care
        // Precondition:  None
        // Postcondition: A list of items stored in the library is returned
        internal List<LibraryItem> GetItemsList()
        {
            return items.Values.ToList();
        }

        // Namespace Helper Method - Use with care
        // Precondition:  None
        // Postcondition: A list of patrons stored in the library is returned
        internal List<LibraryPatron> GetPatronsList()
        {
            return patrons.Values.ToList();
        }
        
        // Precondition:  None
        // Postcondition: A string is returned presenting the libary in a formatted report
        public override string ToString()
        {
            // Using StringBuilder to show use of a more efficient way than String concatenation
            StringBuilder report = new StringBuilder(); // Will hold report as being built
            string NL = Environment.NewLine; // NewLine shortcut

            report.Append("Library Report\n");
            report.Append($"Number of items stored:      {GetItemCount(),4:d}{NL}");
            report.Append($"Number of items checked out: {GetCheckedOutCount(),4:d}{NL}");
            report.Append($"Number of patrons stored:    {GetPatronCount(),4:d}");

            return report.ToString();
        }
    }
}
