﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    class DescendingCopyrightOrder : Comparer<LibraryItem>
    {
        public override int Compare(LibraryItem x, LibraryItem y)
        {
            if (t1 == null && t2 == null) // Both null?
                return 0;                 // Equal

            if (t1 == null) // only t1 is null?
                return -1;  // null is less than any actual time

            if (t2 == null) // only t2 is null?
                return 1;   // Any actual time is greater than null

            if (x.CopyrightYear == y.CopyrightYear)
            {
                return 0;
            }
            else if (x.CopyrightYear > y.CopyrightYear)
                return 1;
            else
                return -1;
        }
    }
}
