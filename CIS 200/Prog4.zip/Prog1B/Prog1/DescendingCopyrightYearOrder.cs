﻿// File: DescendingCopyrightYearOrder.cs
// By: D1972
// This class provides an IComparer for the LibraryItem class
// that orders the objects by copyright year in descending order


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    class DescendingCopyrightYearOrder : Comparer<LibraryItem>
    {

        // Precondition:  None
        // Postcondition: Sorts by copyright year, descending
        //                When x < y, method returns positive #
        //                When x == y, method returns zero
        //                When x > y, method returns negative #
        public override int Compare(LibraryItem x, LibraryItem y)
        {
            if (x == null && y == null) // Both null?
                return 0;                 // Equal

            if (x == null) // only t1 is null?
                return -1;  // null is less than any actual time

            if (y == null) // only t2 is null?
                return 1;   // Any actual time is greater than null

            if (x.CopyrightYear == y.CopyrightYear)
            {
                return 0;
            }
            else if (x.CopyrightYear > y.CopyrightYear)
                return -1;
            else
                return 1;
        }
    }
}
