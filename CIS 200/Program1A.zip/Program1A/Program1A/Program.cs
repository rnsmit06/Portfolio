﻿//Grading ID: D1972
//Program 1A
//Due: 2/15/2017
//CIS 200-01
//This class is used to test the library objects. 


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1A
{
    class Program
    {
        static void Main(string[] args)
        {
            LibraryPatron patron1 = new LibraryPatron("Ryan Smith", "0001");


            LibraryBook book1 = new LibraryBook("BIBLE", "JESUS", "Church", 2000, 30, "001");
            Console.WriteLine(book1.CalcLateFee(1));
            //Console.WriteLine(book1);

            LibraryMovie movie1 = new LibraryMovie("Transformers", "MM", 1990, 20, "002", 55.40, "Michael", LibraryMovie.MediaType.DVD, LibraryMovie.MPAARatings.PG13);
            movie1.CheckOut(patron1);
            Console.WriteLine(movie1);
            movie1.ReturnToShelf();
            Console.WriteLine(movie1);
            Console.WriteLine(movie1.CalcLateFee(60));
            Console.WriteLine();

            LibraryMusic music1 = new LibraryMusic("Highlughts", "MM", 2005, 25, "001", 4.50, "Kanye", LibraryMusic.MediaType.CD, 1);
            Console.WriteLine(music1);
            Console.WriteLine(music1.CalcLateFee(80));

            LibraryJournal journal1 = new LibraryJournal("Diary", "Publisher", 1996, 20, "003", 1, 2, "Personal", "Jane");
            Console.WriteLine(journal1); 
           
        }
    }
}
