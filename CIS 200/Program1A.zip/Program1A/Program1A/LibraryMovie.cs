﻿//Grading ID: D1972
//Program 1A
//Due: 2/15/2017
//CIS 200-01
//This class IS-A LibraryMediaItem. It adds new properties specific to movies and is able to calculate the late fee for the different type
//of media that movies can be.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1A
{
    public class LibraryMovie : LibraryMediaItem
    {

        private string _director;                       //The movie's director
        private MediaType _medium;                      //The movie's medium
        private MPAARatings _rating;                    //The movie's rating
        private const decimal LATE_FEE_LIMIT = 25;      //The highest late fee possible for a movie
        private const decimal DVD_MEDIA_FEE = 1.00m;    //The fee per day for a DVD
        private const decimal VHS_MEDIA_FEE = 1.00m;    //The fee per day for a VHS
        private const decimal BLURAY_MEDIA_FEE = 1.50m; //The fee per day for a BLURAY


        // Precondition: title, callNumber, and director must not be null or empty, theCopyrightYear >= 0, theLoanPeriod >= 0, duration >= 0
        // Postcondition: The LibraryMovie has been initialized with the specified values
        public LibraryMovie(string title, string publisher, int copyrightYear, int loanPeriod, string callNumber, double duration, string director, MediaType medium, MPAARatings rating)
            :base(title, publisher,copyrightYear,loanPeriod,callNumber,duration)
        {
            Director = director;
            Medium = medium;
            Rating = rating;
        }
        
        public enum MPAARatings 
        {
                G, PG, PG13, R, NC17, U
        }

        public string Director
        {
            // Precondition: None
            // Postcondition: The director is returned
            get
            {
                return _director;
            }
            // Precondition:  value must not be null or empty
            // Postcondition: The director has been set to the specified value
            set
            {
                if (!string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    _director = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Director)}", value,
                        $"{nameof(Director)} must not be null or empty");
            }

        }


        public override MediaType Medium
        {
            // Precondition: None
            // Postcondition: The Medium is returned
            get
            {
                return _medium;
            }
            //Precondition: value <= MediaType.VHS (2)
            //Postcondition: Medium is set to the specified value
            set
            {
                if (value <= MediaType.VHS)
                {
                    _medium = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }

        public MPAARatings Rating
        {
            //Precondition: None
            //Postcondition: The Rating is returned
            get
            {
                return _rating;
            }
            //Precondition: value <= MPAARatings.U (5)
            //Postcondition: The Rating is set to the specified value
            set
            {
                if (value <= MPAARatings.U)
                    _rating = value;
                else
                    throw new ArgumentOutOfRangeException();
            }
        }

        // Precondition: days >= 0
        // Postcondition: The price of the late fee is returned
        public override decimal CalcLateFee(int days)
        {
            decimal lateFee = 0;

            if (days < 0)
            {
                throw new ArgumentOutOfRangeException($"{nameof(days)}", days,
                    $"{nameof(days)} must be >= 0");
            }

            if (days - LoanPeriod > 0)
            {
                if (Medium.Equals(MediaType.DVD))
                    lateFee = (days - LoanPeriod) * DVD_MEDIA_FEE;
                else if (Medium.Equals(MediaType.VHS))
                    lateFee = (days - LoanPeriod) * VHS_MEDIA_FEE;
                else if (Medium.Equals(MediaType.BLURAY))
                    lateFee = (days - LoanPeriod) * BLURAY_MEDIA_FEE;
                else
                    lateFee = 0;
             }

            if (lateFee > LATE_FEE_LIMIT)
                lateFee = LATE_FEE_LIMIT;

            return lateFee;
        }


        // Precondition: None
        // Postcondition: A formatted string with the movie's data on different lines is returned
        public override string ToString()
        {
            return "Director: " + Director + Environment.NewLine + 
                "Rating: " + Rating + Environment.NewLine +
                base.ToString();
        }
    }
}
