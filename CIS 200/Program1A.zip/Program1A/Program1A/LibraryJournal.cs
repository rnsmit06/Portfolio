﻿//Grading ID: D1972
//Program 1A
//Due: 2/15/2017
//CIS 200-01
//This class IS-A LibraryPeriodical. It establishes properties specific to journals and provides a method to calculate a journals late fee. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1A
{
    public class LibraryJournal : LibraryPeriodical
    {

        private string _discipline; //The journal's discipline
        private string _editor;     //The journal's editor
        private const decimal JOURNAL_LATE_FEE = 0.75m; //The journal's late fee per day

        // Precondition: title, callNumber, discipline, and editor
        // must not be null or empty, copyrightYear >= 0, loanPeriod >= 0, volume >= 1, number >= 1
        // Postcondition: The LibraryPeriodical has been initialized with the specified values
        public LibraryJournal(string title, string publisher, int copyrightYear, int loanPeriod, string callNumber, int volume, int number,
            string discipline, string editor)
            : base(title, publisher, copyrightYear, loanPeriod, callNumber, volume, number)
        {
            Discipline = discipline;
            Editor = editor;
        }

        public string Discipline
        {
            // Precondition:  None
            // Postcondition: The discipline has been returned
            get
            {
                return _discipline;
            }

            // Precondition:  value must not be null or empty
            // Postcondition: The discipline has been set to the specified value
            set
            {
                if (!string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    _discipline = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Discipline)}", value,
                        $"{nameof(Discipline)} must not be null or empty");
            }
        }

        public string Editor
        {
            // Precondition:  None
            // Postcondition: The editor has been returned
            get
            {
                return _editor;
            }

            // Precondition:  value must not be null or empty
            // Postcondition: The editor has been set to the specified value
            set
            {
                if (!string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    _editor = value.Trim();
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Editor)}", value,
                        $"{nameof(Editor)} must not be null or empty");
            }
        }

        // Precondition: days >= 0
        // Postcondition: The price of the late fee is returned
        public override decimal CalcLateFee(int days)
        {
            if (days < 0)
            {
                throw new ArgumentOutOfRangeException($"{nameof(days)}", days,
                    $"{nameof(days)} must be >= 0");
            }


            if (days - LoanPeriod > 0)
                return (days - LoanPeriod) * JOURNAL_LATE_FEE;
            else
                return 0;
        }


        // Precondition: None
        // Postcondition: A formatted string with the journal's data on different lines is returned
        public override string ToString()
        {
            return "Discipline: " + Discipline + Environment.NewLine +
                "Editor: " + Editor + Environment.NewLine +
            base.ToString();


        }

    }
}
