﻿//Grading ID: D1972
//Program 1A
//Due: 2/15/2017
//CIS 200-01
//This class serves as the base class for media items, adding new properties duration and abstract property medium.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1A
{
    public abstract class LibraryMediaItem : LibraryItem
    {

        private double _duration; //The media item's duration


        // Precondition: title and callNumber must not be null or empty, theCopyrightYear >= 0, theLoanPeriod >= 0, duration >= 0
        // Postcondition: The LibraryMediaItem has been initialized with the specified values
        public LibraryMediaItem(string title, string publisher, int copyrightYear, int loanPeriod, string callNumber, double duration)
            :base(title, publisher, copyrightYear, loanPeriod, callNumber)
        {
            Duration = duration;
        }

        //The media item's media type 
        public enum MediaType
        {
             DVD, BLURAY, VHS, CD ,SACD, VINYL
        }

        //Derived classes will have a Medium
        public abstract MediaType Medium
        {
            get; set;
        }


        public double Duration
        {
            // Precondition: None
            // Postcondition: The duration has been returned
            get
            {
                return _duration;
            }
            // Precondition: value >= 0
            // Postcondition: The duration has been set to the specified value
            set
            {
                if (value >= 0)
                    _duration = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
                        $"{nameof(Duration)} must be >= 0");
            }

        }


        // Precondition: None
        // Postcondition: A formatted string with the MediaItem's data on different lines is returned
        public override string ToString()
        {
            return "Medium: " + Medium + Environment.NewLine
                +"Duration: " + Duration + Environment.NewLine
                + base.ToString();

        }
    }
}
