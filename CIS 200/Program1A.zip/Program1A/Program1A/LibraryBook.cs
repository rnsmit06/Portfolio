﻿//Grading ID: D1972
//Program 1A
//Due: 2/15/2017
//CIS 200-01
//This class establishes an author property for library books and establishes the late fee for books.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1A
{
    class LibraryBook : LibraryItem
    {

        private string _author; //The book's author
        private const decimal BOOK_LATE_FEE = 0.25m; //The book's late fee per day




        // Precondition: theTitle and theCallNumber must not be null or empty, theCopyrightYear >= 0, theLoanPeriod >= 0
        // Postcondition: The LibraryBook has been initialized with the specified values
        public LibraryBook(string title, string author, string publisher, int copyrightYear, int loanPeriod, string callNumber)
            : base(title, publisher, copyrightYear, loanPeriod, callNumber)
        {
            _author = author;
        }

        public string Author
        {
            // Precondition:  None
            // Postcondition: The author has been returned
            get
            {
                return _author;
            }

            // Precondition:  None
            // Postcondition: The author has been set to the specified value
            set
            {
                // Since empty author is OK, just change null to empty string
                _author = (value == null ? string.Empty : value.Trim());
            }
        }


        // Precondition: days >= 0
        // Postcondition: The price of the late fee is returned
        public override decimal CalcLateFee(int days)
        {
            if (days < 0) {
                throw new ArgumentOutOfRangeException($"{nameof(days)}", days,
                    $"{nameof(days)} must be >= 0");
            }


            if (days - LoanPeriod > 0)
                return (days - LoanPeriod) * BOOK_LATE_FEE;
            else
                return 0;    
         }

        // Precondition: None
        // Postcondition: A formatted string with the book's data on different lines is returned
        public override string ToString()
        {
            return "Author: " + Author + Environment.NewLine + base.ToString();
        }
    }
}
