﻿//Grading ID: D1972
//Program 1A
//Due: 2/15/2017
//CIS 200-01
//This class IS-A LibraryMediaItem and adds new properties for music specific items. It can calculate the late fee for music.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1A
{
    public class LibraryMusic : LibraryMediaItem
    {
        private string _artist;                 //The music's artist
        private int _numberOfTracks;            //The music's number of tracks
        private MediaType _medium;              //The music's medium
        private decimal MUSIC_LATE_FEE = 0.50m; //The music's late fee per day
        private decimal LATE_FEE_LIMIT = 20.0m; //The highest late fee possible for music

        // Precondition: title and callNumber must not be null or empty, theCopyrightYear >= 0, theLoanPeriod >= 0, duration >= 0, numberOfTracks >= 1
        // Postcondition: The LibraryMusic has been initialized with the specified values
        public LibraryMusic(string title, string publisher, int copyrightYear, int loanPeriod, string callNumber, double duration, string artist, MediaType medium, int numberOfTracks)
            :base(title, publisher, copyrightYear, loanPeriod, callNumber, duration)
        {
            Artist = artist;
            NumberOfTracks = numberOfTracks;
            Medium = medium;
        }

        public string Artist
        {
            // Precondition:  None
            // Postcondition: The artist has been returned
            get
            {
                return _artist;
            }

            // Precondition:  None
            // Postcondition: The artist has been set to the specified value
            set
            {
                // Since empty artist is OK, just change null to empty string
                _artist = (value == null ? string.Empty : value.Trim());
            }
        }


        public override MediaType Medium
        {
            // Precondition: None
            // Postcondition: The Medium is returned
            get
            {
                return _medium;
            }
            //Precondition: value > MediaType.VHS (2) && value <= MediaType.VINYL (5)
            //Postcondition: Medium is set to the specified value
            set
            {
                if (value > MediaType.VHS && value <= MediaType.VINYL)
                {
                    _medium = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }


        public int NumberOfTracks
        {
            //Precondition: None
            //Postcondition: The number of tracks has been returned
            get
            {
                return _numberOfTracks;
            }
            //Precondition: value >= 1
            //Postcondition: The number of tracks has been set to the specified value
            set
            {
                if (value >= 1)
                    _numberOfTracks = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(NumberOfTracks)}", value,
                        $"{nameof(NumberOfTracks)} must be >= 1");
            }
        }

        // Precondition: days >= 0
        // Postcondition: The price of the late fee is returned
        public override decimal CalcLateFee(int days)
        {
            decimal lateFee;

            if (days < 0)
            {
                throw new ArgumentOutOfRangeException($"{nameof(days)}", days,
                    $"{nameof(days)} must be >= 0");
            }

            if (days - LoanPeriod > 0)
                lateFee = (days - LoanPeriod) * MUSIC_LATE_FEE;
            else
                lateFee = 0;

            if (lateFee > LATE_FEE_LIMIT)
                lateFee = LATE_FEE_LIMIT;

            return lateFee;
        }

        // Precondition: None
        // Postcondition: A formatted string with the music's data on different lines is returned
        public override string ToString()
        {
            return "Artist: " + Artist + Environment.NewLine +
                "Number of tracks: " + NumberOfTracks + Environment.NewLine +
                base.ToString();
        }

    }
}
