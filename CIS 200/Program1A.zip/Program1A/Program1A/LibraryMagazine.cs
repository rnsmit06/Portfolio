﻿//Grading ID: D1972
//Program 1A
//Due: 2/15/2017
//CIS 200-01
//This class IS-A LibraryPeriodical. It establishes the late fee specifications for magazines. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1A
{
    public class LibraryMagazine : LibraryPeriodical
    {

        private const decimal LATE_FEE_LIMIT = 20.00m;   //Highest late fee allowed for magazines 
        private const decimal MAGAZINE_LATE_FEE = 0.25m; //Magazine late fee per day

        // Precondition: title and callNumber must not be null or empty, copyrightYear >= 0, loanPeriod >= 0, volume >= 1, number >= 1
        // Postcondition: The LibraryPeriodical has been initialized with the specified values
        public LibraryMagazine(string title, string publisher, int copyrightYear, int loanPeriod, string callNumber, int volume, int number)
            : base(title, publisher, copyrightYear, loanPeriod, callNumber, volume, number)
        {
        }

        // Precondition: days >= 0
        // Postcondition: The price of the late fee is returned
        public override decimal CalcLateFee(int days)
        {
            decimal lateFee;

            if (days < 0)
            {
                throw new ArgumentOutOfRangeException($"{nameof(days)}", days,
                    $"{nameof(days)} must be >= 0");
            }

            if (days - LoanPeriod > 0)
                lateFee = (days - LoanPeriod) * MAGAZINE_LATE_FEE;
            else
                lateFee = 0;

            if (lateFee > LATE_FEE_LIMIT)
                lateFee = LATE_FEE_LIMIT;

            return lateFee;
        }


        // Precondition: None
        // Postcondition: A formatted string with the magazine's data on different lines is returned
        public override string ToString()
        {
            return base.ToString();
        }

    }
}
