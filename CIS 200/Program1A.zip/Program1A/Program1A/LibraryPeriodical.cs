﻿//Grading ID: D1972
//Program 1A
//Due: 2/15/2017
//CIS 200-01
//This class serves as the base class for periodical's. It establishes properties common to all periodical's.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1A
{
    public abstract class LibraryPeriodical : LibraryItem
    {

        private int _volume;  //The periodical's volume 
        private int _number;  //The periodical's number


        // Precondition: title and callNumber must not be null or empty, copyrightYear >= 0, loanPeriod >= 0, volume >= 1, number >= 1
        // Postcondition: The LibraryPeriodical has been initialized with the specified values
        public LibraryPeriodical(string title, string publisher, int copyrightYear, int loanPeriod, string callNumber, int volume, int number)
            : base(title, publisher, copyrightYear, loanPeriod, callNumber)
        {
            Volume = volume;
            Number = number;
        }

        public int Volume
        {
            //Precondition: None
            //Postcondition: The volume is returned
            get
            {
                return _volume;
            }
            //Precondition: value >= 1
            //Postcondition: The volume has been set to the specified value
            set
            {
                if (value >= 1)
                    _volume = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Volume)}", value,
                        $"{nameof(Volume)} must be >= 1");
            }
        }

        public int Number
        {
            //Precondition: None
            //Postcondition: The number is returned
            get
            {
                return _number;
            }
            //Precondition: value >= 1
            //Postcondition: The number has been set to the specified value
            set
            {
                if (value >= 1)
                    _number = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Number)}", value,
                        $"{nameof(Number)} must be >= 1");
            }
        }


        // Precondition: None
        // Postcondition: A formatted string with the periodical's data on different lines is returned
        public override string ToString()
        {
            return "Volume: " + Volume + Environment.NewLine +
                "Number: " + Number + Environment.NewLine +
            base.ToString();


        }



    }


}
