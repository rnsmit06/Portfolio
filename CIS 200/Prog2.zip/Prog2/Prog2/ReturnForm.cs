﻿//Grading ID: D1972
//Program 2
//Due 3/9/2017
//CIS 200-01
//This is the form to return a checked out item

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ReturnForm : Form
    {

        internal int returnSelectedIndex; //The index of the item to be returned 


        //Precondition: None
        //Postcondition: The ReturnForm GUI has been initialized
        public ReturnForm()
        {
            InitializeComponent();
        }

        //Precondition: Focus attempts to change from bookComboBox
        //Postcondition: Focus is stopped if data is invalid and error is shown
        private void bookComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (bookComboBox.SelectedIndex == -1)
            {
                e.Cancel = true;
                errorProvider1.SetError(bookComboBox, "Please select a book");

            }
        }

        //Precondition: bookComboBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void bookComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(bookComboBox, "");
        }

        //Precondition: Cancel button is left clicked
        //Postcondition: DialogResult is set to DialogResult.Cancel
        private void cancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) //Was it a left click?
            {
                this.DialogResult = DialogResult.Cancel;
            }
        }

        //Precondition: Return button is clicked
        //Postcondition: If data is valid DialogResult is set to DialogResult.OK 
        private void returnButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                returnSelectedIndex = bookComboBox.SelectedIndex;
                this.DialogResult = DialogResult.OK;
            }
        }
    }
}
