﻿//Grading ID: D1972
//Program 2
//Due 3/9/2017
//CIS 200-01
//This is the form to accept input for a new book.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class BookForm : Form
    {

        private string _inputTitle;         //Backing field
        private string _inputPublisher;     //Backing field
        private int _inputCopyrightYear;    //Backing field
        private int _inputLoanPeriod;       //Backing field
        private string _inputCallNumber;    //Backing field
        private string _inputAuthor;        //Backing field


        //Precondition: None
        //Postcondition: The BookForm GUI has been initialized
        public BookForm()
        {
            InitializeComponent();
        }

        
        //Property to hold user input for title
        internal string InputTitle
        {
            //Precondition: None
            //Postcondition _inputTitle has been returned
            get { return _inputTitle; }
            //Precondition: None
            //Postcondition: _inputTitle has been set to titleTextBox.Text
            set { _inputTitle = titleTextBox.Text; }
        }

        //Property for user input for publisher
        internal string InputPublisher
        {
            //Precondition: None
            //Postcondition _inputPublisher has been returned
            get { return _inputPublisher;}
            //Precondition: None
            //Postcondition: _inputPublisher has been set to publisherTextBox.Text
            set { _inputPublisher = publisherTextBox.Text; }
        }

        //Property for user input for call number
        internal string InputCallNumber
        {
            //Precondition: None
            //Postcondition _inputCallNumber has been returned
            get { return _inputCallNumber; }
            //Precondition: None
            //Postcondition: _inputCallNumber has been set to callNumberTextBox.Text
            set { _inputCallNumber = callNumberTextBox.Text; }
        }

        //Property for user input for author
        internal string InputAuthor
        {
            //Precondition: None
            //Postcondition _inputAuthor has been returned
            get { return _inputAuthor; }
            //Precondition: None
            //Postcondition: _inputAuthor has been set to authorTextBox.Text
            set { _inputAuthor = authorTextBox.Text; }
        }

        //Property for user input for coypright year 
        internal int InputCopyrightYear
        {
            //Precondition: None
            //Postcondition _inputCopyrightYear has been returned
            get { return _inputCopyrightYear; }
            //Precondition: None
            //Postcondition: _inputCopyrightYear has been set to copyrightTextBox.Text
            set { _inputCopyrightYear = int.Parse(copyrightTextBox.Text); }
        }

        //Property for user input for loan period
        internal int InputLoanPeriod
        {
            //Precondition: None
            //Postcondition _inputLoanPeriod has been returned
            get { return _inputLoanPeriod; }
            //Precondition: None
            //Postcondition: _inputLoanPeriod has been set to loanPeriodTextBox.Text
            set { _inputLoanPeriod = int.Parse(loanPeriodTextBox.Text); }
        }

        //Precondition: Focus attempts to change from titleTextBox
        //Postcondition: Focus is stopped if data is invalid and error is shown
        private void titleTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (titleTextBox.Text.Trim() == "" || titleTextBox.Text.Trim() == null)
            {
                e.Cancel = true; //Stops focus changing

                errorProvider1.SetError(titleTextBox, "Please enter a valid title");
                titleTextBox.SelectAll();
            }
            else
                InputTitle = titleTextBox.Text;
        }

        //Precondition: titleTextBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void titleTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(titleTextBox, "");
        }

      

        //Precondition: Focus attempts to change from copyrightTextBox
        //Postcondition: Focus is stopped if data is invalid and error is shown
        private void copyrightTextBox_Validating(object sender, CancelEventArgs e)
        {
            int copyrightYear;
            if (!int.TryParse(copyrightTextBox.Text, out copyrightYear) || copyrightYear < 0)
            {
                e.Cancel = true; //Stops focus changing

                errorProvider1.SetError(copyrightTextBox, "Please enter a valid copyright year (int > 0)");
                copyrightTextBox.SelectAll();
            }
            else
                InputCopyrightYear = copyrightYear; ;
        }

        //Precondition: copyrightTextBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void copyrightTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(copyrightTextBox, "");
        }

        //Precondition: Focus attempts to change from loanPeriodTextBox
        //Postcondition: Focus is stopped if data is invalid and error is shown
        private void loanPeriodTextBox_Validating(object sender, CancelEventArgs e)
        {
            int loanPeriod;
            if (!int.TryParse(loanPeriodTextBox.Text, out loanPeriod) || loanPeriod < 0)
            {
                e.Cancel = true; //Stops focus changing

                errorProvider1.SetError(loanPeriodTextBox, "Please enter a valid loan period (int > 0)");
                loanPeriodTextBox.SelectAll();
            }
            else
                InputLoanPeriod = loanPeriod; ;
        }

        //Precondition: loanPeriodTextBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void loanPeriodTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(loanPeriodTextBox, "");
        }

        //Precondition: Focus attempts to change from callNumberTextBox
        //Postcondition: Focus is stopped if data is invalid and error is shown
        private void callNumberTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (callNumberTextBox.Text.Trim() == "" || callNumberTextBox.Text.Trim() == null)
            {
                e.Cancel = true; //Stops focus changing

                errorProvider1.SetError(callNumberTextBox, "Please enter a valid call number");
                callNumberTextBox.SelectAll();
            }
            else
                InputCallNumber = callNumberTextBox.Text;
        }

        //Precondition: callNumberTextBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void callNumberTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(callNumberTextBox, "");
        }


        //Precondition: OK button is clicked
        //Postcondition: If data is valid DialogResult is set to DialogResult.OK 
        private void okButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            this.DialogResult = DialogResult.OK;
        }

        //Precondition: Cancel button is left clicked
        //Postcondition: DialogResult is set to DialogResult.Cancel
        private void cancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) //Was it a left click?
            {
                this.DialogResult = DialogResult.Cancel;
            }
        }

    }
}
