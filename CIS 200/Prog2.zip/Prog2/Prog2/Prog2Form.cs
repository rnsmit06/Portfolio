﻿//Grading ID: D1972
//Program 2
//Due 3/9/2017
//CIS 200-01
//This is the main form that will interact with the library object and process requests to add information to the library and display information about the library.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{

    public partial class Prog2Form : Form
    {

        public Library theLibrary = new Library(); //The library variable that the GUI will interact with


        //Precondition: None
        //Postcondition: The Prog2Form GUI is initialized
        public Prog2Form()
        {
            InitializeComponent();

            //Adding in sample data
            theLibrary.AddPatron("Ima Reader", "12345");
            theLibrary.AddPatron("Jane Doe", "11223");
            theLibrary.AddPatron("John Smith", "54321");
            theLibrary.AddPatron("James T. Kirk", "98765");
            theLibrary.AddPatron("Jean-Luc Picard", "33456");

            theLibrary.AddLibraryBook("The Wright Guide to C#", "UofL Press", 2010, 14,
            "ZZ25 3G", "Andrew Wright");
            theLibrary.AddLibraryBook("Harriet Pooter", "Stealer Books", 2000, 21,
            "AB73 ZF", "IP Thief");
            theLibrary.AddLibraryBook("Goosebumps", "Penguin House", 1996, 20, "AZ29", "R.L. Stine");
            theLibrary.AddLibraryMovie("Andrew's Super-Duper Movie", "UofL Movies", 2011, 7,
            "MM33 2D", 92.5, "Andrew L. Wright", LibraryMediaItem.MediaType.BLURAY,
            LibraryMovie.MPAARatings.PG);
            theLibrary.AddLibraryMovie("Pirates of the Carribean: The Curse of C#", "Disney Programming", 2012, 10,
            "MO93 4S", 122.5, "Steven Stealberg", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.G);
            theLibrary.AddLibraryMusic("C# - The Album", "UofL Music", 2014, 14,
                "CD44 4Z", 84.3, "Dr. A", LibraryMediaItem.MediaType.CD, 10);
            theLibrary.AddLibraryMusic("The Sounds of Programming", "Soundproof Music", 1996, 21,
            "VI64 1Z", 65.0, "Cee Sharpe", LibraryMediaItem.MediaType.VINYL, 12);
            theLibrary.AddLibraryJournal("Journal of C# Goodness", "UofL Journals", 2000, 14,
            "JJ12 7M", 1, 2, "Information Systems", "Andrew Wright");
            theLibrary.AddLibraryJournal("Journal of VB Goodness", "UofL Journals", 2008, 14,
            "JJ34 3F", 8, 4, "Information Systems", "Alexander Williams");
            theLibrary.AddLibraryMagazine("C# Monthly", "UofL Mags", 2016, 14,
            "MA53 9A", 16, 7);
            theLibrary.AddLibraryMagazine("C# Monthly", "UofL Mags", 2016, 14,
            "MA53 9B", 16, 8);
            theLibrary.AddLibraryMagazine("C# Monthly", "UofL Mags", 2016, 14,
                "MA53 9C", 16, 9);
            theLibrary.AddLibraryMagazine("VB Magazine", "UofL Mags", 2017, 14,
            "MA21 5V", 1, 1);









        }

        //Precondition: The Item - Return button has been clicked
        //Postcondition: A dialog box has been displayed prompting for input
        //               If user submits, the selected book is returned
        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReturnForm returnForm = new ReturnForm();       //ReturnForm dialog box
            List<LibraryItem> items;                        // List to hold all the library items
            items = theLibrary.GetItemsList();              // Assigns all the library items to the list

            // Adds every LibraryBook in the library to the bookComboBox
            foreach (LibraryBook i in items)
            {
                returnForm.bookComboBox.Items.Add(i.Title + ", " + i.CallNumber);
            }

            DialogResult result;                 // Result from dialog - OK/Cancel?
            result = returnForm.ShowDialog();  // Show dialog box form

            if (result == DialogResult.OK) //Only do if user submits OK
            {
                //Checks out the selected item to the selected patron
                theLibrary.ReturnToShelf(returnForm.returnSelectedIndex);

            }


        }


        //Precondition: The Item - Check Out button has been clicked
        //Postcondition: A dialog box has been displayed prompting for input
        //               If user submits, the selected book is checked out to the selected patron
        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {

            CheckOutForm checkOutForm = new CheckOutForm(); // CheckOutForm dialog box
            List<LibraryItem> items;                        // List to hold all the library items
            items = theLibrary.GetItemsList();              // Assigns all the library items to the list

            List<LibraryPatron> patrons;                    // List to hold all the library patrons
            patrons = theLibrary.GetPatronsList();          // Assigns all the patrons to the list

            // Adds every LibraryBook in the library to the bookComboBox
            foreach (LibraryItem i in items)
            {
                checkOutForm.bookComboBox.Items.Add(i.Title + ", " +  i.CallNumber);
            }

            // Adds every patron in the library to the patronComboBox
            foreach (LibraryPatron p in patrons)
            {
                checkOutForm.patronComboBox.Items.Add(p.PatronName + ", " + p.PatronID);
            }

            DialogResult result;                 // Result from dialog - OK/Cancel?
            result = checkOutForm.ShowDialog();  // Show dialog box form

            if (result == DialogResult.OK) //Only do if user submits OK
            {
                //Checks out the selected item to the selected patron
                theLibrary.CheckOut(checkOutForm.bookSelectedIndex, checkOutForm.patronSelectedIndex);

            }
        }

        //Precondition: The File - About menu button has been clicked
        //Postcondition: A message box is displayed giving information about the application
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Grading ID: D1972 \n" 
                + "Program 2\n"
                + "Due 3/9/2017\n"
                + "CIS 200-01\n");
        }

        //Precondition: The File - Exit menu button has been clicked
        //Postcondition: The entire application is closed
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        //Precondition: The Report - Patron List menu button has been clicked.
        //Postcondition: A formatted list containing all the patrons has been displayed
        private void patronListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int patronCount = theLibrary.GetPatronCount(); //Total patrons
            StringBuilder result = new StringBuilder();
            result.Append("Count of patrons: " + patronCount.ToString() //String to be outputted
                +  Environment.NewLine + "List of patrons:" + Environment.NewLine);
            List<LibraryPatron> patrons;
            patrons = theLibrary.GetPatronsList();

            foreach (LibraryPatron p in patrons)
            {
                result.Append(p.ToString() + Environment.NewLine + Environment.NewLine);
                
            }
            outputTextBox.Text = result.ToString();
        }

        //Precondition: The Report - Item List menu button has been clicked
        //Postcondition: A formatted list containing all the items has been displayed
        private void itemListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int itemCount = theLibrary.GetItemCount();

            StringBuilder result = new StringBuilder();
            result.Append("Count of items: " + itemCount.ToString() + Environment.NewLine +
                "List of items: " + Environment.NewLine);

            List<LibraryItem> items;
            items = theLibrary.GetItemsList();

            foreach(LibraryItem i in items)
            {
                result.Append(Environment.NewLine + i.ToString() + Environment.NewLine);
            }

            outputTextBox.Text = result.ToString();

        }

        //Precondition: The Insert - Patron menu button has been clicked
        //Postcondition: A dialog box has been displayed prompting for patron data
        //               If user submits, a patron is added to the library with the data provided
        private void patronToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PatronForm patronForm = new PatronForm(); //PatronForm dialog box
            DialogResult result;                      //Result from dialog - OK/Cancel?
            result = patronForm.ShowDialog();         //Show dialog box form
            
            if(result == DialogResult.OK) //Only do if the user chose OK
            {
                //A patron is added to the library using the data inputted 
                theLibrary.AddPatron(patronForm.InputName, patronForm.InputID);
            }

        }

        //Precondition: The Insert - Book menu button has been clicked
        //Postcondition: A dialog box has been displayed prompting for book data
        //               If user submits, a book is added to the library with the data provided
        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookForm bookForm = new BookForm();              //BookForm dialog box
            DialogResult result;                             //Result from dialog
            result = bookForm.ShowDialog();                  //Show dialog box form 

            if(result == DialogResult.OK) //Only do if the user chose OK
            {
                //A book is added to the library using the data inputted 
                theLibrary.AddLibraryBook(bookForm.InputTitle, bookForm.InputPublisher, bookForm.InputCopyrightYear, bookForm.InputLoanPeriod, bookForm.InputCallNumber, bookForm.InputAuthor);
            }

        }

        //Precondition: The Report - Checked Out Items List menu button has been clicked
        //Postcondition: A formatted list containing all the checked out items has been displayed
        private void checkedOutItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int checkedOutCount = 0;            //Total items checked out
            List<LibraryItem> items;            //All the items in the library
            items = theLibrary.GetItemsList();  //Populates the list
            List<LibraryItem> checkedOutItems = new List<LibraryItem>();    //Only the items that are checked out

            //If the item is checked out it is added to the checked out list and checkedOutCount is incremented
            foreach (LibraryItem i in items)
            {
                if(i.IsCheckedOut() == true)
                {
                    checkedOutCount++;
                    checkedOutItems.Add(i);
                }
            }

            StringBuilder outputResult = new StringBuilder(); //StringBuilder for the output 
            outputResult.Append("Count of checked out items: " + checkedOutCount.ToString() + Environment.NewLine +
    "List of checked out items: " + Environment.NewLine);

            foreach (LibraryItem i in checkedOutItems)
            {
                outputResult.Append(Environment.NewLine + i.ToString() + Environment.NewLine);
            }
            outputTextBox.Text = outputResult.ToString();

        }



    }
}
