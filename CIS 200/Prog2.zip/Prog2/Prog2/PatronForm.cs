﻿//Grading ID: D1972
//Program 2
//Due 3/9/2017
//CIS 200-01
//This is the form to accept input for a new patron.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class PatronForm : Form
    {

        private string _inputName; //Backing field
        private string _inputID; //Backing field


        //Precondition: None
        //Postcondition: The PatronForm GUI has been initialized
        public PatronForm()
        {
            InitializeComponent();
        }

        //Name property
        internal string InputName
        {
            //Precondition: None
            //Postcondition _inputName has been returned
            get { return _inputName; }

            //Precondition: None
            //Postcondition: _inputName has been set to patronNameTextBox.Text
            set { _inputName = patronNameTextBox.Text; }
        }

        internal string InputID
        {
            //Precondition: None
            //Postcondition _inputID has been returned
            get { return _inputID; }

            //Precondition: None
            //Postcondition: _inputID has been set to patronIDTextBox.Text
            set { _inputID = patronIDTextBox.Text; }
        }


        //Precondition: Focus attempts to change from patronNameTextBox
        //Postcondition: Focus is stopped if data is invalid and error is shown
        private void patronNameTextBox_Validating(object sender, CancelEventArgs e)
        {

            InputName = patronNameTextBox.Text;

            //If patronNameTextBox is null or empty then stop focus from changing and show error
            if(InputName.Trim() == "" || InputName.Trim() == null)
            {
                e.Cancel = true; //Stops focus changing
                errorProvider1.SetError(patronNameTextBox, "Please enter a valid patron name");
                patronNameTextBox.SelectAll();
            }
        }

        //Precondition: patronNameTextBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void patronNameTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(patronNameTextBox, "");
        }


        //Precondition: Focus attempts to change from patronIDTextBox
        //Postcondition: Focus is stopped if data is invalid and error is shown
        private void patronIDTextBox_Validating(object sender, CancelEventArgs e)
        {
          
            InputID = patronIDTextBox.Text;

            if (InputID.Trim() == "" || InputID.Trim() == null)
            {
                e.Cancel = true; //Stops focus changing

                errorProvider1.SetError(patronIDTextBox, "Please enter a valid patron ID");
                patronIDTextBox.SelectAll();
            }
        }

        //Precondition: patronIDTextBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void patronIDTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(patronIDTextBox, "");
        }



        //Precondition: OK button is clicked
        //Postcondition: If data is valid DialogResult is set to DialogResult.OK 
        private void patronOKButton_Click(object sender, EventArgs e)
        {
           if(this.ValidateChildren())
            this.DialogResult = DialogResult.OK;
        }

        //Precondition: Cancel button is left clicked
        //Postcondition: DialogResult is set to DialogResult.Cancel
        private void patronCancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) //Was it a left click?
            {
                this.DialogResult = DialogResult.Cancel;
            }
        }


    }
}
