﻿//Grading ID: D1972
//Program 2
//Due 3/9/2017
//CIS 200-01
//This is the form to check out an item

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class CheckOutForm : Form
    {


        internal int bookSelectedIndex;     //Variable to represent the index of the checked out item
        internal int patronSelectedIndex;   //Variable to represent the index of the patron



        //Precondition: None
        //Postcondition: The CheckOutForm GUI has been initialized
        public CheckOutForm()
        {
            InitializeComponent();
        }


        //Precondition: Focus attempts to change from bookComboBox
        //Postcondition: Focus is stopped from changing if no item is selected
        private void bookComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (bookComboBox.SelectedIndex == -1)
            {
                e.Cancel = true;
                errorProvider1.SetError(bookComboBox, "Please select a book");

            }
        }

        //Precondition: bookComboBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void bookComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(bookComboBox, "");
        }

        //Precondition: Focus attempts to change from patronComboBox
        //Postcondition: Focus is stopped from changing if no patron is selected
        private void patronComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (patronComboBox.SelectedIndex == -1)
            {
                e.Cancel = true;
                errorProvider1.SetError(patronComboBox, "Please select a book");

            }
        }

        //Precondition: patronComboBox_Validating has succeeded
        //Postcondition: The error is cleared
        private void patronComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(patronComboBox, "");

        }


        //Precondition: Check out button is clicked
        //Postcondition: If data is valid DialogResult is set to DialogResult.OK, bookSelectedIndex and patronSelectedIndex are set
        private void checkOutButton_Click(object sender, EventArgs e)
        {
            {
                if (this.ValidateChildren())
                {
                    bookSelectedIndex = bookComboBox.SelectedIndex;
                    patronSelectedIndex = patronComboBox.SelectedIndex;
                    this.DialogResult = DialogResult.OK;

                }
            }
        }

        //Precondition: Cancel button is left clicked
        //Postcondition: DialogResult is set to DialogResult.Cancel
        private void cancelButton_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) //Was it a left click?
            {
                this.DialogResult = DialogResult.Cancel;
            }
        }
    }
}
