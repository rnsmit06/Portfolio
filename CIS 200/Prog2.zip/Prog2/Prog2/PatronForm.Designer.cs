﻿namespace LibraryItems
{
    partial class PatronForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.patronNameTextBox = new System.Windows.Forms.TextBox();
            this.patronIDTextBox = new System.Windows.Forms.TextBox();
            this.patronNameLabel = new System.Windows.Forms.Label();
            this.patronIDLabel = new System.Windows.Forms.Label();
            this.patronOKButton = new System.Windows.Forms.Button();
            this.patronCancelButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // patronNameTextBox
            // 
            this.patronNameTextBox.Location = new System.Drawing.Point(85, 73);
            this.patronNameTextBox.Name = "patronNameTextBox";
            this.patronNameTextBox.Size = new System.Drawing.Size(133, 20);
            this.patronNameTextBox.TabIndex = 0;
            this.patronNameTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.patronNameTextBox_Validating);
            this.patronNameTextBox.Validated += new System.EventHandler(this.patronNameTextBox_Validated);
            // 
            // patronIDTextBox
            // 
            this.patronIDTextBox.Location = new System.Drawing.Point(85, 149);
            this.patronIDTextBox.Name = "patronIDTextBox";
            this.patronIDTextBox.Size = new System.Drawing.Size(133, 20);
            this.patronIDTextBox.TabIndex = 1;
            this.patronIDTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.patronIDTextBox_Validating);
            this.patronIDTextBox.Validated += new System.EventHandler(this.patronIDTextBox_Validated);
            // 
            // patronNameLabel
            // 
            this.patronNameLabel.AutoSize = true;
            this.patronNameLabel.Location = new System.Drawing.Point(92, 57);
            this.patronNameLabel.Name = "patronNameLabel";
            this.patronNameLabel.Size = new System.Drawing.Size(115, 13);
            this.patronNameLabel.TabIndex = 2;
            this.patronNameLabel.Text = "Enter the patron name:";
            // 
            // patronIDLabel
            // 
            this.patronIDLabel.AutoSize = true;
            this.patronIDLabel.Location = new System.Drawing.Point(92, 133);
            this.patronIDLabel.Name = "patronIDLabel";
            this.patronIDLabel.Size = new System.Drawing.Size(100, 13);
            this.patronIDLabel.TabIndex = 3;
            this.patronIDLabel.Text = "Enter the patron ID:";
            // 
            // patronOKButton
            // 
            this.patronOKButton.Location = new System.Drawing.Point(167, 215);
            this.patronOKButton.Name = "patronOKButton";
            this.patronOKButton.Size = new System.Drawing.Size(75, 23);
            this.patronOKButton.TabIndex = 4;
            this.patronOKButton.Text = "Ok";
            this.patronOKButton.UseVisualStyleBackColor = true;
            this.patronOKButton.Click += new System.EventHandler(this.patronOKButton_Click);
            // 
            // patronCancelButton
            // 
            this.patronCancelButton.Location = new System.Drawing.Point(62, 215);
            this.patronCancelButton.Name = "patronCancelButton";
            this.patronCancelButton.Size = new System.Drawing.Size(75, 23);
            this.patronCancelButton.TabIndex = 5;
            this.patronCancelButton.Text = "Cancel";
            this.patronCancelButton.UseVisualStyleBackColor = true;
            this.patronCancelButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.patronCancelButton_MouseDown);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // PatronForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 294);
            this.Controls.Add(this.patronCancelButton);
            this.Controls.Add(this.patronOKButton);
            this.Controls.Add(this.patronIDLabel);
            this.Controls.Add(this.patronNameLabel);
            this.Controls.Add(this.patronIDTextBox);
            this.Controls.Add(this.patronNameTextBox);
            this.Name = "PatronForm";
            this.Text = "PatronForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox patronIDTextBox;
        private System.Windows.Forms.Label patronNameLabel;
        private System.Windows.Forms.Label patronIDLabel;
        private System.Windows.Forms.Button patronOKButton;
        private System.Windows.Forms.Button patronCancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TextBox patronNameTextBox;
    }
}