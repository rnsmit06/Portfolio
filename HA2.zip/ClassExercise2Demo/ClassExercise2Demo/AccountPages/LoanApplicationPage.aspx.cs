﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassExercise2Demo.MyClasses;

namespace ClassExercise2Demo.AccountPages
{
    public partial class LoanApplicationPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //Account account = ((Account)HttpContext.Current.Session["Account"]);
  


        protected void submitButton_Click(object sender, EventArgs e)
        {
            Account account = ((Account)Session["Account"]);
            //Age > 18 & Loan < Balance from previous page & loan < .5 * Salary
            if (Convert.ToInt64(ageTextBox.Text) > 18 && Convert.ToInt64(loanTextBox.Text) < .5 * Convert.ToInt64(salaryTextBox.Text))
            {
                //Checking balance
                if(Convert.ToInt64(loanTextBox.Text) < account.Balance)
                {
                    loanApprovalLabel.Text = "Congratulations!! Your loan is approved.";
                }
                else
                    loanApprovalLabel.Text = "Your loan is not approved. Sorry!!";

            }
            else
                loanApprovalLabel.Text = "Your loan is not approved. Sorry!!";

        }
    }
}