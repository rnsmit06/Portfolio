﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassExercise2Demo.MyClasses;

namespace ClassExercise2Demo.AccountPages
{
    public partial class AccountDetails : System.Web.UI.Page
    {

        private Account account;

        protected void Page_Load(object sender, EventArgs e)
        {
            List<Account> allAccounts = (List<Account>)Session["AllAccounts"];
            Customer cust = (Customer)Session["customer"];


            if(PreviousPage != null)
            {
                int selectedIndex = ((ListBox)PreviousPage.FindControl("AccountListBox")).SelectedIndex;
                //Find details of selected account

                Account selectedAccount = allAccounts[selectedIndex];
                account = selectedAccount;
                accountNameLabel.Text = selectedAccount.Nickname;
                accountTypeLabel.Text = selectedAccount.Type;
                accountBalanceLabel.Text = selectedAccount.Balance.ToString();
                loanLabel.Text = selectedAccount.HasLoanOffer().ToString();
                addressLabel.Text = cust.FullAddress;
                Session["Account"] = account;



            }
        }

        protected void withdrawButton_Click(object sender, EventArgs e)
        {
            Account account = ((Account)Session["Account"]);
            double withdraw = Convert.ToDouble(withdrawTextBox.Text);
            if(withdraw < account.Balance)
            {
                //New Balance
                account.Balance = account.Balance - withdraw;
                accountBalanceLabel.Text = account.Balance.ToString();
                Session["Account"] = account;

            }

           

        }
    }
}