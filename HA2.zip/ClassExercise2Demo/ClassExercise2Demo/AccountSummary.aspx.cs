﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassExercise2Demo.MyClasses;

namespace ClassExercise2Demo
{
    public partial class AccountSummary : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GenerateSessionObjects sessionObjs = new GenerateSessionObjects();
            List<Account> acctList = (List<Account>)Session["AllAccounts"];

            Customer cust = (Customer)Session["customer"];

            NameLabel.Text = cust.FullName;

            foreach(Account a in acctList)
            {
                AccountListBox.Items.Add(a.Nickname);
            }
        }

        protected void DetailsButton_Click(object sender, EventArgs e)
        {
            
        }
    }
}