﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClassExercise2Demo.MyClasses
{
    public class Customer
    {
        private string _fullAddress;
        private string _fullName;
        public Customer(string name, string add)
        {
            _fullName = name;
            _fullAddress = add;
        }

        public string FullAddress
        {
            get { return _fullAddress; }       
        }

        public string FullName
        {
            get { return _fullName; }
        }


    }
}