﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClassExercise2Demo.MyClasses
{
    public class GenerateSessionObjects
    {
        List<Account> allAccounts = new List<Account>();
        public GenerateSessionObjects()
        {
            Account a1 = new Account();
            Account a2 = new Account();
            Account a3 = new Account();
            a1.Type = "Checking";
            a1.Balance = 30123.45;
            a1.Nickname = "My chk1";
            a2.Type = "Checking";
            a2.Balance = 20123.45;
            a2.Nickname = "My chk2";
            a3.Type = "Savings";
            a3.Balance = 22675.98;
            a3.Nickname = "My sav1";
            allAccounts.Add(a1);
            allAccounts.Add(a2);
            allAccounts.Add(a3);

            Customer cust1 = new Customer("Daniel Bert", "1234 Louisville Lane");

            HttpContext.Current.Session["customer"] = cust1;
            HttpContext.Current.Session["AllAccounts"] = allAccounts;



        }

    }
}