﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClassExercise2Demo.MyClasses
{
    public class Account
    {
        private string _type;
        private double _balance;
        private string _nickname;

        public string Type
        {
            get { return _type;}
           set  { _type = value;   }
        }
        public double Balance
        {
            get { return _balance; }
            set { _balance = value; }
        }

        public string Nickname
        {
            get { return _nickname; }
            set { _nickname = value;  }
        }

        public Boolean HasLoanOffer()
        {
            if (Balance < 15000)
                return false;
            else
                return true;
        }
    }
}