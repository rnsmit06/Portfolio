﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment1Q5
{
    public partial class Assignment1Q5 : System.Web.UI.Page
    {
        double savingsBalance = 30345.90;
        double checkingBalance = 40785.22;
        double studentBalance = 5643.23;
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            if (!IsPostBack)
            {
                accountDropDown.Items.Add("Savings Account");
                accountDropDown.Items.Add("Checking Account");
                accountDropDown.Items.Add("Student Account");
            }
        }

        protected void withdrawlButton_Click(object sender, EventArgs e)
        {
            double withdrawl = Convert.ToDouble(withdrawlTextBox.Text);
            //Savings
            if(accountDropDown.SelectedIndex == 0)
            {
                if (withdrawl > savingsBalance)
                    withdrawlLabel.Text = "Withdrawl is greater than the balance which is " + savingsBalance.ToString("C") + ".";
                else
                {
                    savingsBalance = savingsBalance - withdrawl;
                    withdrawlLabel.Text = "Withdrawl successful. Your new balance is " + savingsBalance.ToString("C") + ".";
                }
            }
            //Checking
            else if(accountDropDown.SelectedIndex == 1)
            {
                if (withdrawl > checkingBalance)
                    withdrawlLabel.Text = "Withdrawl is greater than the balance which is " + checkingBalance.ToString("C") + ".";
                else
                {
                    checkingBalance = checkingBalance - withdrawl;
                    withdrawlLabel.Text = "Withdrawl successful. Your new balance is " + checkingBalance.ToString("C") + ".";
                }
            }
            //Student
            else
            {
                if (withdrawl > studentBalance)
                    withdrawlLabel.Text = "Withdrawl is greater than the balance which is " + studentBalance.ToString("C") + ".";
                else
                {
                    studentBalance = studentBalance - withdrawl;
                    withdrawlLabel.Text = "Withdrawl successful. Your new balance is " + studentBalance.ToString("C") + ".";
                }
            }
        }
    }
}